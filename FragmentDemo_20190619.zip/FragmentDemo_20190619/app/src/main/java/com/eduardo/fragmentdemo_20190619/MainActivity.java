package com.eduardo.fragmentdemo_20190619;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.eduardo.fragmentdemo_20190619.ui.Constants;
import com.eduardo.fragmentdemo_20190619.ui.fragments.AFragment;
import com.eduardo.fragmentdemo_20190619.ui.fragments.BFragment;
import com.eduardo.fragmentdemo_20190619.ui.fragments.CFragment;
import com.eduardo.fragmentdemo_20190619.ui.fragments.DefaultFragment;

/** Created by
        Eduardo Castillo S */

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AFragment.OnInteractionListernerFragmentA {

    Button btnFragmentA;
    Button btnFragmentB;
    Button btnFragmentC;
    Button btnRemoveFragmentA;
    Button btnRemoveFragmentB;
    Button btnRemoveFragmentC;
    TextView tvResultado;
    FrameLayout flContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initXML();
        initDefaultFragment();
    }

    @Override
    public void onInteraction(String msg) {
        tvResultado.setText(msg);
    }

    @Override
    public void onClick(View v) {
        Fragment fragment = null;
        String tag = "";
        switch (v.getId()){
            case R.id.btn_fragment_a:
                fragment = new AFragment();
                initFragmentBackstack(fragment, Constants.FRAGMENT_A);
                break;
            case R.id.btn_fragment_b:
                fragment = new BFragment();
                initFragmentBackstack(fragment, Constants.FRAGMENT_B);
                break;
            case R.id.btn_fragment_c:
                fragment = new CFragment();
                initFragmentBackstack(fragment, Constants.FRAGMENT_C);
                break;
            case R.id.btn_remove_fragment_a:
                tag = Constants.FRAGMENT_A;
                removeFragment(tag);
                break;
            case R.id.btn_remove_fragment_b:
                tag = Constants.FRAGMENT_B;
                removeFragment(tag);
                break;
            case R.id.btn_remove_fragment_c:
                tag = Constants.FRAGMENT_C;
                removeFragment(tag);
                break;
        }
    }

    void initXML(){
        flContainer = findViewById(R.id.fl_container);
        btnFragmentA = findViewById(R.id.btn_fragment_a);
        btnFragmentB = findViewById(R.id.btn_fragment_b);
        btnFragmentC = findViewById(R.id.btn_fragment_c);
        tvResultado = findViewById(R.id.tv_resultado);
        btnRemoveFragmentA = findViewById(R.id.btn_remove_fragment_a);
        btnRemoveFragmentB = findViewById(R.id.btn_remove_fragment_b);
        btnRemoveFragmentC = findViewById(R.id.btn_remove_fragment_c);

        btnFragmentA.setOnClickListener(this);
        btnFragmentB.setOnClickListener(this);
        btnFragmentC.setOnClickListener(this);
        btnRemoveFragmentA.setOnClickListener(this);
        btnRemoveFragmentB.setOnClickListener(this);
        btnRemoveFragmentC.setOnClickListener(this);
    }

    void initDefaultFragment(){
        Fragment fragment = new DefaultFragment();
        String tag = Constants.DEFAULT_FRAGMENT;
        initFragment(fragment,tag);
    }

    void initFragment(Fragment fragment, String tag){
        /* If 'add' is used instead of 'replaced', previous fragments will not be removed. */
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.fl_container,fragment, tag);
        ft.commitNow();
    }

    /*
    addToBackStack sirve para almacenar en la pila los fragments anteriors
     */
    void initFragmentBackstack(Fragment fragment, String tag){
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        Fragment toRemove = fm.findFragmentById(R.id.fl_container);//Para ello debe existir un fragment cargado al menos
        if (fragment!=null){
            ft.remove(toRemove);
            ft.add(R.id.fl_container, fragment);
            ft.addToBackStack("BACKSTACK_TAG");
            ft.commit();
        } else {
            return;
        }
    }

    //Remove no va trabajar si se usa backstack
    void removeFragment(String tag){
        FragmentManager fm = getSupportFragmentManager();
        Fragment fragment = fm.findFragmentByTag(tag);
        if(fragment != null){
            FragmentTransaction ft = fm.beginTransaction();
            ft.remove(fragment);
            ft.commitNow();
        } else {
            return;
        }
    }
}
