package com.eduardo.fragmentdemo_20190619.ui;

public class Constants {
    public static final String FRAGMENT_A = "Fragment_A";
    public static final String FRAGMENT_B = "Fragment_B";
    public static final String FRAGMENT_C = "Fragment_C";
    public static final String DEFAULT_FRAGMENT= "Default_Fragment";
}
