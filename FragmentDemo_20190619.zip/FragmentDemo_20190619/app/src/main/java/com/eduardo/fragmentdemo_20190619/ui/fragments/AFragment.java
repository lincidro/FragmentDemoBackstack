package com.eduardo.fragmentdemo_20190619.ui.fragments;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.eduardo.fragmentdemo_20190619.MainActivity;
import com.eduardo.fragmentdemo_20190619.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class AFragment extends Fragment {

    Button btnFragmentA;
    EditText etFragmentA;
    OnInteractionListernerFragmentA listenerA;

    public AFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_a, container, false);
        initXML(view);
        return view;
    }

    //3 Validar si el contexto implementa la interface declarada en este fragment
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof OnInteractionListernerFragmentA){
            listenerA = (OnInteractionListernerFragmentA) context;
        } else {
            throw new RuntimeException(context.toString()+" implementar OnInteractionListernerFragmentA");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listenerA = null;
    }

    //Inicializar elementos
    private void initXML(View v){
        etFragmentA = v.findViewById(R.id.et_nombre_a);
        btnFragmentA = v.findViewById(R.id.btn_fragment_a);

        btnFragmentA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = etFragmentA.getText().toString();
                listenerA.onInteraction(msg);
            }
        });
    }

    //1 Crear la interface
    public interface OnInteractionListernerFragmentA{
        void onInteraction(String msg);
    }
}
